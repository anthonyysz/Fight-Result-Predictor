"""UFC event scraping package."""

