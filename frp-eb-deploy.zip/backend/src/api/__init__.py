"""FastAPI admin API package."""
